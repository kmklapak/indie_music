# Be sure to restart your server when you modify this file.

IndieMusic::Application.config.session_store :cookie_store, key: '_indie_music_session'
