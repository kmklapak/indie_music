class ActionController::TestCase
  include Devise::TestHelpers
end